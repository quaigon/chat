package com.example.kamil.chat;

public class User {
    public int id;
    public String login;
    public String www;

    public User(int id, String login, String www) {
        this.id = id;
        this.login = login;
        this.www = www;
    }
}
