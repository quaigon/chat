package com.example.kamil.chat;

public class MessageContainer {
    public Message message;

    public Message getMessage() {
        return message;
    }
}
